public interface Observador {
    void recibirNotificacion(Notificacion notificacion);
}
